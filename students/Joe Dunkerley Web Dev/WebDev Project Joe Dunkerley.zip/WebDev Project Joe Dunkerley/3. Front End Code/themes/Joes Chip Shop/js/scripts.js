/* ----------------- Start Document ----------------- */
(function($){
	$(document).ready(function(){
		'use strict';

/*----------------------------------------------------*/
/*	 Foundation - http://foundation.zurb.com/docs
/*----------------------------------------------------*/
	$(document).foundation();

/* ------------------ End Document ------------------ */
});
	
})(this.jQuery);
